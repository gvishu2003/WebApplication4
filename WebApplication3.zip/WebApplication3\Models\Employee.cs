﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication3.Models
{
    public class Employee
    {
        public string cEmployeeName { get; set; }
        public string cFatherspouceName { get; set; }
        public int cEmployeeCode { get; set; }

        

    }

    
}